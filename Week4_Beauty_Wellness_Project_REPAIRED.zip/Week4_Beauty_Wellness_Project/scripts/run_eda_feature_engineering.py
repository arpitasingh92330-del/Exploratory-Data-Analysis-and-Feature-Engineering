from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw" / "synthetic_beauty_reviews.csv"
OUT = ROOT / "data" / "processed" / "cleaned_engineered_reviews.csv"
TABLES = ROOT / "outputs" / "tables"
FIGURES = ROOT / "outputs" / "figures"
LOGS = ROOT / "outputs" / "logs"
for path in (OUT.parent, TABLES, FIGURES, LOGS): path.mkdir(parents=True, exist_ok=True)

raw = pd.read_csv(RAW)
required = ["review_id", "product_id", "category", "price_inr", "size_ml", "rating", "review_date", "review_text"]
missing = [col for col in required if col not in raw.columns]
if missing: raise ValueError(f"Required columns missing: {missing}")

df = raw.copy()
df["price_inr"] = pd.to_numeric(df["price_inr"], errors="coerce")
df["size_ml"] = pd.to_numeric(df["size_ml"], errors="coerce")
df["rating"] = pd.to_numeric(df["rating"], errors="coerce")
df["review_date"] = pd.to_datetime(df["review_date"], errors="coerce")
df["review_text"] = df["review_text"].fillna("").astype(str).str.strip()
df["category"] = df["category"].astype("string").str.strip().str.title()
duplicate_ids = int(df["review_id"].duplicated().sum())
df = df.drop_duplicates(subset=["review_id"], keep="first").copy()
valid = df["review_id"].notna() & df["product_id"].notna() & df["rating"].between(1, 5) & df["review_date"].notna()
df.loc[~valid].to_csv(OUT.parent / "quarantine_invalid_rows.csv", index=False)
df = df.loc[valid].copy()
df["rating"] = df["rating"].round().astype(int)

df["price_per_100ml"] = np.where(df["size_ml"] > 0, df["price_inr"] / (df["size_ml"] / 100), np.nan)
df["log_price_inr"] = np.log1p(df["price_inr"].clip(lower=0))
df["price_band"] = pd.cut(df["price_inr"], [-np.inf, 499.99, 1499.99, np.inf], labels=["Budget (<₹500)", "Mid (₹500–1,499)", "Premium (₹1,500+)"])
df["rating_group"] = np.select([df["rating"] <= 2, df["rating"] == 3, df["rating"] >= 4], ["Low (1–2)", "Neutral (3)", "High (4–5)"], default="Unknown")
df["review_length_chars"] = df["review_text"].str.len()
df["review_word_count"] = df["review_text"].str.findall(r"\b\w+\b").str.len()
df["review_year_month"] = df["review_date"].dt.to_period("M").astype(str)
df["review_month"] = df["review_date"].dt.month
df["review_weekday"] = df["review_date"].dt.day_name()
df["is_weekend"] = df["review_date"].dt.dayofweek >= 5
text = df["review_text"].str.lower()
positive = ["soft", "smooth", "pleasant", "gentle", "hydrating", "natural", "easy", "comfortable", "useful", "reasonable", "works", "worked", "shine"]
negative = ["irritation", "redness", "sticky", "dry", "leaked", "difficult", "strong", "unpleasant", "rough", "dull", "not", "did not", "discomfort"]
df["positive_word_count"] = text.apply(lambda x: sum(x.count(w) for w in positive))
df["negative_word_count"] = text.apply(lambda x: sum(x.count(w) for w in negative))
df["lexicon_sentiment_score"] = df["positive_word_count"] - df["negative_word_count"]
for col, terms in {"mentions_hydration":["hydrat","moisture","dry"], "mentions_texture":["texture","sticky","smooth","residue"], "mentions_irritation":["irritation","redness","discomfort"], "mentions_fragrance":["fragrance","scent","smell"], "mentions_packaging":["packaging","pump","cap","leak"], "mentions_shade_match":["shade","colour","color"], "mentions_wear_time":["wear time","touch-up","last very long"]}.items():
    df[col] = text.apply(lambda x: int(any(term in x for term in terms)))
std = df["price_inr"].std(ddof=0)
df["price_zscore"] = (df["price_inr"] - df["price_inr"].mean()) / std if std else 0
df["price_x_review_length"] = df["log_price_inr"] * df["review_word_count"]
# This target-derived field is kept only for descriptive checks; never use it as a predictor for rating.
df["rating_x_irritation_theme"] = df["rating"] * df["mentions_irritation"]
df.to_csv(OUT, index=False)

rating = df.groupby("rating").size().rename("count").reset_index(); rating["share_pct"] = 100 * rating["count"] / len(df); rating.to_csv(TABLES / "rating_distribution.csv", index=False)
cat = df.groupby("category").agg(n_reviews=("review_id", "size"), mean_rating=("rating", "mean"), median_rating=("rating", "median"), low_rating_share=("rating", lambda s: (s <= 2).mean()), high_rating_share=("rating", lambda s: (s >= 4).mean()), median_price_inr=("price_inr", "median")).reset_index(); cat.to_csv(TABLES / "category_summary.csv", index=False)
price = df.groupby("price_band", observed=True).agg(n_reviews=("review_id", "size"), mean_rating=("rating", "mean"), median_price_inr=("price_inr", "median"), low_rating_share=("rating", lambda s: (s <= 2).mean())).reset_index(); price.to_csv(TABLES / "price_band_summary.csv", index=False)
monthly = df.groupby("review_year_month").agg(n_reviews=("review_id", "size"), mean_rating=("rating", "mean")).reset_index(); monthly.to_csv(TABLES / "monthly_summary.csv", index=False)
miss = df.isna().mean().mul(100).rename("missing_pct").reset_index().rename(columns={"index":"field"}); miss.to_csv(TABLES / "missingness_profile.csv", index=False)
groups = [g["rating"].to_numpy() for _, g in df.groupby("category")]
k = stats.kruskal(*groups) if len(groups) > 1 else None
rho = stats.spearmanr(df["price_inr"], df["rating"])
tab = pd.crosstab(df["mentions_irritation"], df["rating"].le(2)); chi = stats.chi2_contingency(tab, correction=False) if tab.shape == (2, 2) else None
summary = {"dataset_type":"SYNTHETIC teaching dataset; not real customer data", "rows_input":int(len(raw)), "rows_accepted":int(len(df)), "unique_products":int(df["product_id"].nunique()), "categories":int(df["category"].nunique()), "mean_rating":float(df["rating"].mean()), "median_rating":float(df["rating"].median()), "low_rating_share_pct":float(100*(df["rating"]<=2).mean()), "kruskal_category_rating":{"statistic":float(k.statistic),"p_value":float(k.pvalue)} if k else None, "spearman_price_rating":{"rho":float(rho.statistic),"p_value":float(rho.pvalue)}, "chi2_irritation_low_rating":{"statistic":float(chi.statistic),"p_value":float(chi.pvalue)} if chi else None, "interpretation":"All results describe synthetic data only; do not generalise to real consumers."}
(LOGS / "eda_run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
sns.set_theme(style="whitegrid", font="DejaVu Sans")
plt.figure(figsize=(8,4.5)); sns.countplot(data=df, x="rating", color="#2B7A78"); plt.title("Synthetic review ratings"); plt.tight_layout(); plt.savefig(FIGURES / "01_rating_distribution.png", dpi=180); plt.close()
plt.figure(figsize=(8,4.5)); sns.barplot(data=cat, x="category", y="mean_rating", color="#5B7C99"); plt.ylim(1,5); plt.title("Mean rating by category (synthetic sample)"); plt.tight_layout(); plt.savefig(FIGURES / "02_mean_rating_by_category.png", dpi=180); plt.close()
plt.figure(figsize=(8,4.5)); sns.boxplot(data=df, x="price_band", y="rating", color="#D9A441"); plt.title("Rating by price band (synthetic sample)"); plt.tight_layout(); plt.savefig(FIGURES / "03_rating_by_price_band.png", dpi=180); plt.close()
plt.figure(figsize=(9,4.5)); monthly["month_dt"] = pd.to_datetime(monthly["review_year_month"]+"-01"); sns.lineplot(data=monthly, x="month_dt", y="n_reviews", marker="o", color="#8B5E83"); plt.xticks(rotation=35, ha="right"); plt.title("Monthly review counts (synthetic sample)"); plt.tight_layout(); plt.savefig(FIGURES / "04_monthly_review_counts.png", dpi=180); plt.close()
print(json.dumps(summary, indent=2))
